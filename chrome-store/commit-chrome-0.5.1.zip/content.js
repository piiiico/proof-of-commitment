// src/extension/auth.ts
var WORLD_ID_APP_ID = "app_a2868bad17534bb7e8bc82de8df73773";
var WORLD_ID_AUTHORIZE_URL = "https://id.worldcoin.org/authorize";
var WORLD_ID_JWKS_URL = "https://id.worldcoin.org/jwks.json";
var WORLD_ID_ISSUER = "https://id.worldcoin.org";
var STORAGE_KEY_AUTH = "auth:credential";
function generateNonce() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(16).padStart(2, "0")).join("");
}
function generateState() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(16).padStart(2, "0")).join("");
}
function base64urlDecode(str) {
  let base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4 !== 0) {
    base64 += "=";
  }
  return atob(base64);
}
function parseJWT(token) {
  const parts = token.split(".");
  if (parts.length !== 3)
    throw new Error("Invalid JWT format");
  const header = JSON.parse(base64urlDecode(parts[0]));
  const payload = JSON.parse(base64urlDecode(parts[1]));
  return { header, payload };
}
async function importJWK(jwk) {
  return crypto.subtle.importKey("jwk", {
    kty: jwk.kty,
    n: jwk.n,
    e: jwk.e,
    alg: jwk.alg,
    use: jwk.use
  }, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
}
async function verifyJWTSignature(token, key) {
  const parts = token.split(".");
  const signedContent = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
  const signatureStr = parts[2].replace(/-/g, "+").replace(/_/g, "/");
  const paddedSig = signatureStr + "=".repeat((4 - signatureStr.length % 4) % 4);
  const signatureBytes = Uint8Array.from(atob(paddedSig), (c) => c.charCodeAt(0));
  return crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, signatureBytes, signedContent);
}
async function fetchSigningKey(kid) {
  const response = await fetch(WORLD_ID_JWKS_URL);
  if (!response.ok) {
    throw new Error(`Failed to fetch JWKS: ${response.status}`);
  }
  const jwks = await response.json();
  const key = jwks.keys.find((k) => k.kid === kid);
  if (!key) {
    throw new Error(`No matching key found for kid: ${kid}`);
  }
  return importJWK(key);
}
async function verifyIdToken(idToken, expectedNonce) {
  const { header, payload } = parseJWT(idToken);
  if (payload.iss !== WORLD_ID_ISSUER) {
    throw new Error(`Invalid issuer: ${payload.iss}`);
  }
  if (payload.aud !== WORLD_ID_APP_ID) {
    throw new Error(`Invalid audience: ${payload.aud}`);
  }
  if (payload.nonce !== expectedNonce) {
    throw new Error("Nonce mismatch");
  }
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) {
    throw new Error("Token expired");
  }
  const signingKey = await fetchSigningKey(header.kid);
  const valid = await verifyJWTSignature(idToken, signingKey);
  if (!valid) {
    throw new Error("Invalid token signature");
  }
  return payload;
}
function getRedirectURL() {
  return chrome.identity.getRedirectURL("/callback");
}
async function signIn() {
  const nonce = generateNonce();
  const state = generateState();
  const redirectUri = getRedirectURL();
  const params = new URLSearchParams({
    client_id: WORLD_ID_APP_ID,
    response_type: "id_token",
    redirect_uri: redirectUri,
    scope: "openid",
    state,
    nonce,
    response_mode: "fragment"
  });
  const authUrl = `${WORLD_ID_AUTHORIZE_URL}?${params.toString()}`;
  const responseUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true
    }, (callbackUrl) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!callbackUrl) {
        reject(new Error("No callback URL received"));
        return;
      }
      resolve(callbackUrl);
    });
  });
  const hashParams = new URLSearchParams(responseUrl.split("#")[1] || "");
  const returnedState = hashParams.get("state");
  if (returnedState !== state) {
    throw new Error("State mismatch — possible CSRF attack");
  }
  const idToken = hashParams.get("id_token");
  if (!idToken) {
    const error = hashParams.get("error");
    const errorDesc = hashParams.get("error_description");
    throw new Error(`Authentication failed: ${error || "no id_token"} — ${errorDesc || "unknown error"}`);
  }
  const payload = await verifyIdToken(idToken, nonce);
  const credential = {
    sub: payload.sub,
    verificationLevel: payload.verification_level || "unknown",
    authenticatedAt: Date.now(),
    idToken
  };
  await chrome.storage.local.set({ [STORAGE_KEY_AUTH]: credential });
  return credential;
}
async function getCredential() {
  const result = await chrome.storage.local.get(STORAGE_KEY_AUTH);
  return result[STORAGE_KEY_AUTH] || null;
}

// src/extension/shop.ts
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
var bare = (h) => h.toLowerCase().replace(/^www\./, "");
function mod11(n) {
  if (!/^[89]\d{8}$/.test(n))
    return false;
  const w = [3, 2, 7, 6, 5, 4, 3, 2];
  const s = w.reduce((a, x, i) => a + x * Number(n[i]), 0);
  const k = 11 - s % 11;
  return (k === 11 ? 0 : k) === Number(n[8]) && k !== 10;
}
var ORG_RE = /(?:org(?:anisasjons)?\.?\s*-?\s*(?:nr|nummer|no)\.?|foretaksregisteret|\bNO)\s*[:.]?\s*(?:NO\s*)?(\d{3}[\s.\u00a0]?\d{3}[\s.\u00a0]?\d{3})(?!\d)/gi;
function findOrgNrs(text) {
  const out = new Set;
  for (const m of text.matchAll(ORG_RE)) {
    const n = m[1].replace(/\D/g, "");
    if (mod11(n))
      out.add(n);
  }
  return [...out];
}
var SENSITIVE_DOMAIN = /(apotek|pharma|farmasi|vitusapotek|boots|helse|klinikk|legesenter|tannlege|psykolog|casino|poker|bet(t|ting)?\b|bet\.|odds|spill|tipping|lotto|dating|tinder|match\.|happn|porn|xxx|sex|onlyfans|escort|kirke|church|moske|parti\b|partiet|bank|kreditt|credit|lan\.|forbruksl|refinans|forsikring)/i;
var SENSITIVE_NACE = /^(64|65|66|86|87|88|92|94)\.|^47\.7[34]/;
var sensitive = (domain, nace) => SENSITIVE_DOMAIN.test(domain) || !!nace && SENSITIVE_NACE.test(nace);
var ORDER_PATH = /(checkout\/(success|complete|confirmation|thank)|order[-_/]?(confirmation|received|complete|success)|ordrebekreftelse|kvittering|bestilling\/(takk|fullfort|bekreftelse)|\/takk(-for-(din-)?(bestilling|handelen|ordren|kjopet))?(\/|$|\?)|\/thank-?you(\/|$|\?))/i;
var ORDER_TEXT = /(takk for (din |di )?(bestilling|ordre|handelen|kjøpet)|ordrebekreftelse|din ordre er (mottatt|bekreftet|registrert)|bestillingen (din )?er mottatt|thank you for your (order|purchase)|order (confirmed|received))/i;
function isOrderPage(path, headline) {
  return ORDER_PATH.test(path) || ORDER_TEXT.test(headline);
}
function kr(x) {
  if (x >= 1e9)
    return `${(x / 1e9).toFixed(1).replace(".", ",")} mrd kr`;
  if (x >= 1e6)
    return `${Math.round(x / 1e6).toLocaleString("nb-NO")} mill. kr`;
  return `${Math.round(x).toLocaleString("nb-NO")} kr`;
}
var norm = (s) => s.toLowerCase().replace(/æ/g, "ae").replace(/ø/g, "o").replace(/å/g, "a").replace(/[^a-z0-9 ]/g, " ");
var STOP = new Set(["as", "asa", "ab", "aps", "norge", "norway", "norden", "nordic", "scandinavia", "group", "holding", "drift", "handel", "og", "the", "ltd", "gmbh", "sa", "nuf", "da", "ans", "ba", "sa"]);
function nameMatches(domain, b) {
  const d = bare(domain);
  if (b.hjemmeside && bare(b.hjemmeside.replace(/^https?:\/\//, "")).split("/")[0] === d)
    return true;
  const label = norm(d.split(".").slice(0, -1).join(" ")).replace(/\s+/g, "");
  const toks = norm(b.navn).split(/\s+/).filter((t) => t.length >= 3 && !STOP.has(t));
  if (toks.some((t) => label.includes(t)))
    return true;
  const joined = toks.join("");
  return joined.length >= 3 && (joined.includes(label) || label.includes(joined));
}
function brregLine(domain, b, now = new Date) {
  const red = [];
  if (b.konkurs)
    red.push("konkurs");
  if (b.avvikling || b.tvang)
    red.push(b.tvang ? "under tvangsavvikling" : "under avvikling");
  if (b.slettet)
    red.push("slettet i Enhetsregisteret");
  const ageMonths = b.start ? (now.getTime() - new Date(b.start).getTime()) / (30.44 * 86400000) : null;
  if (ageMonths !== null && ageMonths < 12 && b.omsetning === null)
    red.push(`registrert ${b.start}, ingen regnskap ennå`);
  if (!nameMatches(domain, b))
    red.push(`org.nr på siden tilhører ${b.navn}, som ikke ligner ${bare(domain)} (grov navnesjekk)`);
  const parts = [titleCase(b.navn)];
  if (b.start)
    parts.push(`i drift siden ${b.start.slice(0, 4)}`);
  if (b.ansatte)
    parts.push(`${b.ansatte.toLocaleString("nb-NO")} ansatte`);
  if (b.omsetning !== null && b.aar)
    parts.push(`omsetning ${b.aar}: ${kr(b.omsetning)}`);
  return { text: parts.join(" · "), red };
}
function titleCase(s) {
  return s.toLowerCase().replace(/(^|[\s-])(\p{L})/gu, (_, a, c) => a + c.toUpperCase()).replace(/\b(As|Asa|Ab|Nuf)\b/g, (x) => x.toUpperCase());
}
function friendLine(fra, r) {
  const yrs = r.y0 === r.y1 ? `${r.y0}` : `${r.y0}–${String(r.y1).slice(2)}`;
  return r.n > 0 ? `${fra}: handlet her ${r.n}× (${yrs})` : `${fra}: kom tilbake hit ${r.m} måneder (${yrs})`;
}
function decodeCard(s) {
  try {
    const bin = atob(s.replace(/-/g, "+").replace(/_/g, "/"));
    const c = JSON.parse(new TextDecoder().decode(Uint8Array.from(bin, (ch) => ch.charCodeAt(0))));
    if (c?.v !== 1 || !Array.isArray(c.rader))
      return null;
    const rader = c.rader.filter((r) => typeof r?.d === "string" && /^[a-z0-9.-]+\.[a-z]{2,}$/.test(r.d) && !sensitive(r.d)).map((r) => ({ d: r.d, n: Math.max(0, r.n | 0), m: Math.max(0, r.m | 0), y0: r.y0 | 0, y1: r.y1 | 0 })).slice(0, 200);
    return { v: 1, fra: String(c.fra || "En venn").slice(0, 40), laget: String(c.laget || "").slice(0, 10), rader };
  } catch {
    return null;
  }
}

// src/extension/shop-content.ts
var S = chrome.storage.local;
var FONT = "font:13px/1.45 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif";
var month = () => new Date().toISOString().slice(0, 7);
async function brreg(orgnr) {
  return chrome.runtime.sendMessage({ type: "commit-brreg", orgnr }).catch(() => null);
}
async function friends(domain) {
  const { "kort:imported": cards = [] } = await S.get("kort:imported");
  const out = [];
  for (const c of cards)
    for (const r of c.rader)
      if (r.d === domain || domain.endsWith("." + r.d))
        out.push(friendLine(c.fra, r));
  return out;
}
function html(domain, b, fr) {
  const rows = fr.map((f) => `<div style="color:#188038"><b>${esc(f)}</b></div>`);
  if (b) {
    const l = brregLine(domain, b);
    rows.push(`<div>${esc(l.text)}</div>`);
    for (const r of l.red)
      rows.push(`<div style="color:#d93025"><b>${esc(r)}</b></div>`);
  }
  return rows.join("");
}
async function shopPage() {
  const domain = bare(location.hostname);
  const text = (document.body?.innerText || "").slice(-400000) + " " + [...document.querySelectorAll("footer")].map((f) => f.textContent || "").join(" ").slice(-1e5);
  const found = findOrgNrs(text);
  const { "shop:org": orgs = {}, "shop:log": log = {} } = await S.get(["shop:org", "shop:log"]);
  let b = null;
  if (found.length) {
    const all = (await Promise.all(found.slice(0, 3).map(brreg))).filter(Boolean);
    b = all.find((x) => nameMatches(domain, x)) || all[0] || null;
    if (b) {
      orgs[domain] = b.orgnr;
      await S.set({ "shop:org": orgs });
    }
  }
  if (orgs[domain] && !sensitive(domain, b?.nace)) {
    const l = log[domain] || { months: [], orders: [] };
    if (!l.months.includes(month()))
      l.months.push(month());
    if (b)
      l.nace = b.nace;
    const head = [document.title, ...[...document.querySelectorAll("h1,h2")].slice(0, 6).map((h) => h.innerText)].join(" | ");
    const key = new Date().toISOString().slice(0, 10) + location.pathname;
    if (isOrderPage(location.pathname, head) && !l.orders.some((o) => o.slice(10) === location.pathname && o.slice(0, 10) === key.slice(0, 10)))
      l.orders.push(key);
    log[domain] = l;
    await S.set({ "shop:log": log });
  }
  const fr = sensitive(domain, b?.nace) ? [] : await friends(domain);
  if (!b && !fr.length)
    return;
  if (document.getElementById("commit-shop-line"))
    return;
  const el = document.createElement("div");
  el.id = "commit-shop-line";
  el.title = "Commit · Brønnøysundregistrene · klikk for å lukke";
  el.style.cssText = `position:fixed;bottom:16px;left:16px;z-index:2147483647;max-width:440px;padding:8px 12px;background:#fff;border:1px solid #dadce0;border-left:3px solid ${b && brregLine(domain, b).red.length ? "#d93025" : "#5f6368"};border-radius:6px;box-shadow:0 2px 10px rgba(0,0,0,.15);${FONT};color:#202124;cursor:pointer`;
  el.innerHTML = html(domain, b, fr) + `<div style="font-size:11px;color:#80868b;margin-top:2px">${b ? `Org.nr ${esc(b.orgnr)} fra siden · Brønnøysundregistrene · ` : ""}Commit (laget av Pico, en AI-agent)</div>`;
  el.addEventListener("click", () => el.remove());
  document.body.appendChild(el);
}
function isSerp() {
  const h = location.hostname;
  return /(^|\.)google\.[a-z.]+$/.test(h) && location.pathname === "/search" || /(^|\.)bing\.com$/.test(h) && location.pathname === "/search" || /(^|\.)duckduckgo\.com$/.test(h);
}
function resultDomain(href) {
  try {
    const u = new URL(href);
    let t = u.searchParams.get("uddg") || "";
    const bu = u.searchParams.get("u");
    if (!t && bu?.startsWith("a1"))
      t = atob(bu.slice(2).replace(/-/g, "+").replace(/_/g, "/"));
    return bare(new URL(t || href).hostname);
  } catch {
    return "";
  }
}
async function serpLines() {
  const { "shop:org": orgs = {} } = await S.get("shop:org");
  const anchors = [...document.querySelectorAll("a[href^='http']")].filter((a) => a.querySelector("h2,h3") || a.closest("h2,h3"));
  const done = new Set;
  for (const a of anchors) {
    const d = resultDomain(a.href);
    if (!d || done.has(d) || /(^|\.)(google|bing|duckduckgo|microsoft)\./.test(d))
      continue;
    done.add(d);
    const fr = sensitive(d) ? [] : await friends(d);
    const b = orgs[d] ? await brreg(orgs[d]) : null;
    if (!b && !fr.length)
      continue;
    const host = a.closest("h2,h3")?.parentElement || a.parentElement;
    if (host.querySelector(":scope > [data-commit-serp]"))
      continue;
    const el = document.createElement("div");
    el.dataset.commitSerp = d;
    el.style.cssText = `${FONT};font-size:12px;margin:2px 0 6px;padding:3px 8px;border-left:3px solid #dadce0;background:#f8f9fa;color:#3c4043`;
    el.innerHTML = html(d, b, fr);
    host.appendChild(el);
  }
}
async function importBar() {
  const m = location.hash.match(/kort=([A-Za-z0-9_-]+)/);
  if (!m)
    return;
  const card = decodeCard(m[1]);
  if (!card || document.getElementById("commit-import-bar"))
    return;
  const bar = document.createElement("div");
  bar.id = "commit-import-bar";
  bar.style.cssText = `position:fixed;top:0;left:0;right:0;z-index:2147483647;padding:12px 16px;background:#202124;color:#fff;${FONT};font-size:14px;text-align:center`;
  const list = card.rader.slice(0, 6).map((r) => esc(r.d)).join(", ") + (card.rader.length > 6 ? ` og ${card.rader.length - 6} til` : "");
  bar.innerHTML = `Kortet til <b>${esc(card.fra)}</b>: ${card.rader.length} ${card.rader.length === 1 ? "butikk" : "butikker"} (${list}). <button id="commit-import">Importer</button>`;
  bar.querySelector("#commit-import").addEventListener("click", async () => {
    const { "kort:imported": cards = [] } = await S.get("kort:imported");
    const next = [...cards.filter((c) => !(c.fra === card.fra && c.laget === card.laget)), card];
    await S.set({ "kort:imported": next });
    bar.innerHTML = `Importert. Du ser nå <b>${esc(card.fra)}</b> på disse butikkene og under søketreffene deres. Fjern kortet i Commit-menyen.`;
  });
  document.body.appendChild(bar);
}

// src/extension/content.ts
var BACKEND_URL = "https://poc-backend.amdal-dev.workers.dev";
function extractGitHubRepo() {
  const match = window.location.pathname.match(/^\/([^/]+)\/([^/]+)/);
  if (!match)
    return null;
  const owner = match[1];
  const repo = match[2];
  if (["features", "pricing", "about", "orgs", "settings", "login", "join"].includes(owner)) {
    return null;
  }
  if (repo.startsWith(".") || owner.startsWith("."))
    return null;
  return { owner, repo };
}
async function fetchGitHubTrust(owner, repo) {
  try {
    const res = await fetch(`${BACKEND_URL}/api/github/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`);
    if (!res.ok)
      return null;
    return await res.json();
  } catch {
    return null;
  }
}
function scoreColor(score) {
  if (score >= 70)
    return "#4ade80";
  if (score >= 45)
    return "#facc15";
  return "#f87171";
}
function formatAge(years) {
  if (years < 0.1)
    return "< 1 month";
  if (years < 1)
    return `${Math.round(years * 12)} months`;
  const y = Math.floor(years);
  const m = Math.round((years - y) * 12);
  if (m === 0)
    return `${y} yr`;
  return `${y} yr ${m} mo`;
}
function injectGitHubPanel(data) {
  if (document.getElementById("commit-gh-panel"))
    return;
  const color = scoreColor(data.score);
  const circumference = 2 * Math.PI * 30;
  const filled = data.score / 100 * circumference;
  const sidebar = document.querySelector(".Layout-sidebar") ?? document.querySelector('[data-target="repos-header.sidebar"]') ?? document.querySelector(".repository-lang-stats-graph")?.parentElement ?? null;
  const panel = document.createElement("div");
  panel.id = "commit-gh-panel";
  panel.style.cssText = `
    background: #f6f8fa;
    border: 1px solid #d0d7de;
    border-radius: 6px;
    padding: 16px;
    margin-bottom: 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    font-size: 12px;
    color: #24292f;
  `;
  panel.innerHTML = `
    <style>
      #commit-gh-panel .commit-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 12px;
      }
      #commit-gh-panel .commit-brand {
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.8px;
        text-transform: uppercase;
        color: #656d76;
      }
      #commit-gh-panel .commit-score-row {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 12px;
      }
      #commit-gh-panel .commit-score-ring {
        position: relative;
        width: 56px;
        height: 56px;
        flex-shrink: 0;
      }
      #commit-gh-panel .commit-score-ring svg {
        transform: rotate(-90deg);
      }
      #commit-gh-panel .commit-score-number {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        font-weight: 700;
        color: #24292f;
      }
      #commit-gh-panel .commit-score-label {
        font-size: 11px;
        color: #656d76;
        line-height: 1.4;
      }
      #commit-gh-panel .commit-signals {
        border-top: 1px solid #d0d7de;
        padding-top: 10px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 6px 12px;
        margin-bottom: 12px;
      }
      #commit-gh-panel .commit-signal {
        display: flex;
        justify-content: space-between;
        font-size: 11px;
      }
      #commit-gh-panel .commit-signal-key {
        color: #656d76;
      }
      #commit-gh-panel .commit-signal-val {
        font-weight: 600;
        color: #24292f;
        font-variant-numeric: tabular-nums;
      }
      #commit-gh-panel .commit-endorse-btn {
        display: block;
        width: 100%;
        padding: 6px 12px;
        background: #24292f;
        color: #fff;
        border: none;
        border-radius: 6px;
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
        text-decoration: none;
        box-sizing: border-box;
      }
      #commit-gh-panel .commit-endorse-btn:hover {
        background: #444c56;
      }
      #commit-gh-panel .commit-footer {
        margin-top: 8px;
        font-size: 10px;
        color: #8c959f;
        text-align: center;
      }
      #commit-gh-panel .commit-footer a {
        color: #8c959f;
        text-decoration: none;
      }
      #commit-gh-panel .commit-footer a:hover { text-decoration: underline; }
    </style>

    <div class="commit-header">
      <span class="commit-brand">Commit Score</span>
    </div>

    <div class="commit-score-row">
      <div class="commit-score-ring">
        <svg width="56" height="56" viewBox="0 0 56 56">
          <circle cx="28" cy="28" r="22" fill="none" stroke="#e5e7eb" stroke-width="5"/>
          <circle cx="28" cy="28" r="22" fill="none" stroke="${color}" stroke-width="5"
            stroke-linecap="round"
            stroke-dasharray="${data.score / 100 * (2 * Math.PI * 22).toFixed(4)} ${(2 * Math.PI * 22).toFixed(4)}"
          />
        </svg>
        <span class="commit-score-number">${data.score}</span>
      </div>
      <div class="commit-score-label">
        <strong>${data.score >= 70 ? "Healthy" : data.score >= 45 ? "Moderate" : "Early stage"}</strong><br/>
        Behavioral trust score
      </div>
    </div>

    <div class="commit-signals">
      <div class="commit-signal">
        <span class="commit-signal-key">Age</span>
        <span class="commit-signal-val">${formatAge(data.signals.ageYears)}</span>
      </div>
      <div class="commit-signal">
        <span class="commit-signal-key">Contributors</span>
        <span class="commit-signal-val">${data.signals.contributors}</span>
      </div>
      <div class="commit-signal">
        <span class="commit-signal-key">Stars</span>
        <span class="commit-signal-val">${data.signals.stars.toLocaleString()}</span>
      </div>
      <div class="commit-signal">
        <span class="commit-signal-key">Commits (30d)</span>
        <span class="commit-signal-val">${data.signals.recentCommits30d}</span>
      </div>
      <div class="commit-signal">
        <span class="commit-signal-key">Endorsements</span>
        <span class="commit-signal-val" id="commit-endorsement-count">${data.endorsements > 0 ? data.endorsements : "None yet"}</span>
      </div>
    </div>

    <button class="commit-endorse-btn" id="commit-endorse-btn">
      Endorse this repo →
    </button>

    <div class="commit-footer">
      <a href="https://getcommit.dev" target="_blank" rel="noopener">getcommit.dev</a>
      · behavioral trust, not stars
    </div>
  `;
  if (sidebar) {
    sidebar.insertBefore(panel, sidebar.firstChild);
  } else {
    const repoHeader = document.querySelector("#repository-container-header") ?? document.querySelector(".repohead") ?? document.querySelector("main > div:first-child");
    if (repoHeader?.parentElement) {
      repoHeader.parentElement.insertBefore(panel, repoHeader.nextSibling);
    } else {
      panel.style.cssText = "position:fixed;top:72px;right:16px;width:300px;z-index:2147483647";
      document.body.appendChild(panel);
    }
  }
  const endorseBtn = panel.querySelector("#commit-endorse-btn");
  if (endorseBtn) {
    endorseBtn.addEventListener("click", async () => {
      endorseBtn.disabled = true;
      endorseBtn.textContent = "Endorsing…";
      try {
        let cred = await getCredential();
        if (!cred) {
          cred = await signIn();
        }
        const res = await fetch(`${BACKEND_URL}/api/repos/${encodeURIComponent(data.owner)}/${encodeURIComponent(data.repo)}/endorse`, { method: "POST", headers: { Authorization: `Bearer ${cred.idToken}` } });
        if (res.ok) {
          const json = await res.json();
          endorseBtn.textContent = json.alreadyEndorsed ? "Already endorsed ✓" : "Endorsed ✓";
          const countEl = document.getElementById("commit-endorsement-count");
          if (countEl)
            countEl.textContent = json.endorsements.toString();
        } else {
          endorseBtn.textContent = "Failed — try again";
          endorseBtn.disabled = false;
        }
      } catch {
        endorseBtn.textContent = "Failed — try again";
        endorseBtn.disabled = false;
      }
    });
  }
}
async function fetchDomainStats(domain) {
  try {
    const res = await fetch(`${BACKEND_URL}/api/domain/${encodeURIComponent(domain)}`);
    if (!res.ok)
      return null;
    return await res.json();
  } catch {
    return null;
  }
}
function injectTrustBadge(stats) {
  if (document.getElementById("commit-trust-badge"))
    return;
  const repeatRate = stats.totalVisits > stats.uniqueCommitments ? Math.round((stats.totalVisits - stats.uniqueCommitments) / stats.totalVisits * 100) : 0;
  let color = "#f87171";
  let bg = "rgba(248, 113, 113, 0.1)";
  if (repeatRate >= 50 && stats.uniqueCommitments >= 5) {
    color = "#4ade80";
    bg = "rgba(74, 222, 128, 0.1)";
  } else if (repeatRate >= 25 || stats.uniqueCommitments >= 3) {
    color = "#facc15";
    bg = "rgba(250, 204, 21, 0.1)";
  }
  const badge = document.createElement("div");
  badge.id = "commit-trust-badge";
  badge.innerHTML = `
    <style>
      #commit-trust-badge {
        position: fixed;
        bottom: 16px;
        right: 16px;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        background: ${bg};
        backdrop-filter: blur(12px);
        border: 1px solid ${color}33;
        border-radius: 20px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 12px;
        color: ${color};
        cursor: pointer;
        transition: opacity 0.3s, transform 0.3s;
        opacity: 0.7;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      }
      #commit-trust-badge:hover { opacity: 1; transform: scale(1.05); }
      #commit-trust-badge .commit-dot {
        width: 6px; height: 6px; border-radius: 50%; background: ${color};
      }
      #commit-trust-badge.commit-dismissed {
        opacity: 0; pointer-events: none; transform: translateY(10px);
      }
    </style>
    <span class="commit-dot"></span>
    <span>${stats.uniqueCommitments} verified visitor${stats.uniqueCommitments !== 1 ? "s" : ""}</span>
  `;
  badge.addEventListener("click", () => {
    badge.classList.add("commit-dismissed");
    setTimeout(() => badge.remove(), 300);
  });
  document.body.appendChild(badge);
}
async function init() {
  const result = await chrome.storage.local.get("config:contributing");
  const contributing = result["config:contributing"] === true;
  const protocol = window.location.protocol;
  if (["chrome:", "chrome-extension:", "about:"].some((p) => protocol === p))
    return;
  const hostname = window.location.hostname;
  if (hostname === "github.com") {
    if (!contributing)
      return;
    const ghRepo = extractGitHubRepo();
    if (ghRepo) {
      const data = await fetchGitHubTrust(ghRepo.owner, ghRepo.repo);
      if (data) {
        injectGitHubPanel(data);
      }
    }
    return;
  }
  if (!contributing)
    return;
  const stats = await fetchDomainStats(hostname);
  if (stats && stats.uniqueCommitments > 0) {
    injectTrustBadge(stats);
  }
}
setTimeout(init, 1500);
setTimeout(() => {
  const run = location.hostname === "getcommit.dev" ? importBar : isSerp() ? serpLines : shopPage;
  run().catch(() => {});
  if (run === serpLines) {
    let t, n = 0;
    const mo = new MutationObserver(() => {
      clearTimeout(t);
      t = setTimeout(() => {
        if (++n > 20)
          return mo.disconnect();
        serpLines().catch(() => {});
      }, 700);
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
  }
}, 1200);
if (window.location.hostname === "github.com") {
  let lastPath = window.location.pathname;
  const observer = new MutationObserver(() => {
    if (window.location.pathname !== lastPath) {
      lastPath = window.location.pathname;
      document.getElementById("commit-gh-panel")?.remove();
      setTimeout(init, 800);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}
