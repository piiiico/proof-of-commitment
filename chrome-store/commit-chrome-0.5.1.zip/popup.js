// src/extension/shop.ts
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
var bare = (h) => h.toLowerCase().replace(/^www\./, "");
var SENSITIVE_DOMAIN = /(apotek|pharma|farmasi|vitusapotek|boots|helse|klinikk|legesenter|tannlege|psykolog|casino|poker|bet(t|ting)?\b|bet\.|odds|spill|tipping|lotto|dating|tinder|match\.|happn|porn|xxx|sex|onlyfans|escort|kirke|church|moske|parti\b|partiet|bank|kreditt|credit|lan\.|forbruksl|refinans|forsikring)/i;
var SENSITIVE_NACE = /^(64|65|66|86|87|88|92|94)\.|^47\.7[34]/;
var sensitive = (domain, nace) => SENSITIVE_DOMAIN.test(domain) || !!nace && SENSITIVE_NACE.test(nace);
function kr(x) {
  if (x >= 1e9)
    return `${(x / 1e9).toFixed(1).replace(".", ",")} mrd kr`;
  if (x >= 1e6)
    return `${Math.round(x / 1e6).toLocaleString("nb-NO")} mill. kr`;
  return `${Math.round(x).toLocaleString("nb-NO")} kr`;
}
var norm = (s) => s.toLowerCase().replace(/æ/g, "ae").replace(/ø/g, "o").replace(/å/g, "a").replace(/[^a-z0-9 ]/g, " ");
var STOP = new Set(["as", "asa", "ab", "aps", "norge", "norway", "norden", "nordic", "scandinavia", "group", "holding", "drift", "handel", "og", "the", "ltd", "gmbh", "sa", "nuf", "da", "ans", "ba", "sa"]);
function nameMatches(domain, b) {
  const d = bare(domain);
  if (b.hjemmeside && bare(b.hjemmeside.replace(/^https?:\/\//, "")).split("/")[0] === d)
    return true;
  const label = norm(d.split(".").slice(0, -1).join(" ")).replace(/\s+/g, "");
  const toks = norm(b.navn).split(/\s+/).filter((t) => t.length >= 3 && !STOP.has(t));
  if (toks.some((t) => label.includes(t)))
    return true;
  const joined = toks.join("");
  return joined.length >= 3 && (joined.includes(label) || label.includes(joined));
}
function brregLine(domain, b, now = new Date) {
  const red = [];
  if (b.konkurs)
    red.push("konkurs");
  if (b.avvikling || b.tvang)
    red.push(b.tvang ? "under tvangsavvikling" : "under avvikling");
  if (b.slettet)
    red.push("slettet i Enhetsregisteret");
  const ageMonths = b.start ? (now.getTime() - new Date(b.start).getTime()) / (30.44 * 86400000) : null;
  if (ageMonths !== null && ageMonths < 12 && b.omsetning === null)
    red.push(`registrert ${b.start}, ingen regnskap ennå`);
  if (!nameMatches(domain, b))
    red.push(`org.nr på siden tilhører ${b.navn}, som ikke ligner ${bare(domain)} (grov navnesjekk)`);
  const parts = [titleCase(b.navn)];
  if (b.start)
    parts.push(`i drift siden ${b.start.slice(0, 4)}`);
  if (b.ansatte)
    parts.push(`${b.ansatte.toLocaleString("nb-NO")} ansatte`);
  if (b.omsetning !== null && b.aar)
    parts.push(`omsetning ${b.aar}: ${kr(b.omsetning)}`);
  return { text: parts.join(" · "), red };
}
function titleCase(s) {
  return s.toLowerCase().replace(/(^|[\s-])(\p{L})/gu, (_, a, c) => a + c.toUpperCase()).replace(/\b(As|Asa|Ab|Nuf)\b/g, (x) => x.toUpperCase());
}
function friendLine(fra, r) {
  const yrs = r.y0 === r.y1 ? `${r.y0}` : `${r.y0}–${String(r.y1).slice(2)}`;
  return r.n > 0 ? `${fra}: handlet her ${r.n}× (${yrs})` : `${fra}: kom tilbake hit ${r.m} måneder (${yrs})`;
}
function encodeCard(c) {
  const bytes = new TextEncoder().encode(JSON.stringify(c));
  let s = "";
  for (const b of bytes)
    s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function cardRows(log) {
  const rows = [];
  for (const [d, l] of Object.entries(log)) {
    if (sensitive(d, l.nace))
      continue;
    const months = [...new Set(l.months)].sort();
    if (months.length < 2 && l.orders.length === 0)
      continue;
    const yrs = [...months, ...l.orders.map((o) => o.slice(0, 7))].map((m) => Number(m.slice(0, 4))).sort();
    rows.push({ d, n: l.orders.length, m: months.length, y0: yrs[0], y1: yrs[yrs.length - 1] });
  }
  return rows.sort((a, b) => b.n - a.n || b.m - a.m);
}
var HISTORY_DAYS = 90;

// src/extension/auth.ts
var WORLD_ID_APP_ID = "app_a2868bad17534bb7e8bc82de8df73773";
var WORLD_ID_AUTHORIZE_URL = "https://id.worldcoin.org/authorize";
var WORLD_ID_JWKS_URL = "https://id.worldcoin.org/jwks.json";
var WORLD_ID_ISSUER = "https://id.worldcoin.org";
var STORAGE_KEY_AUTH = "auth:credential";
function generateNonce() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(16).padStart(2, "0")).join("");
}
function generateState() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(16).padStart(2, "0")).join("");
}
function base64urlDecode(str) {
  let base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4 !== 0) {
    base64 += "=";
  }
  return atob(base64);
}
function parseJWT(token) {
  const parts = token.split(".");
  if (parts.length !== 3)
    throw new Error("Invalid JWT format");
  const header = JSON.parse(base64urlDecode(parts[0]));
  const payload = JSON.parse(base64urlDecode(parts[1]));
  return { header, payload };
}
async function importJWK(jwk) {
  return crypto.subtle.importKey("jwk", {
    kty: jwk.kty,
    n: jwk.n,
    e: jwk.e,
    alg: jwk.alg,
    use: jwk.use
  }, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
}
async function verifyJWTSignature(token, key) {
  const parts = token.split(".");
  const signedContent = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
  const signatureStr = parts[2].replace(/-/g, "+").replace(/_/g, "/");
  const paddedSig = signatureStr + "=".repeat((4 - signatureStr.length % 4) % 4);
  const signatureBytes = Uint8Array.from(atob(paddedSig), (c) => c.charCodeAt(0));
  return crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, signatureBytes, signedContent);
}
async function fetchSigningKey(kid) {
  const response = await fetch(WORLD_ID_JWKS_URL);
  if (!response.ok) {
    throw new Error(`Failed to fetch JWKS: ${response.status}`);
  }
  const jwks = await response.json();
  const key = jwks.keys.find((k) => k.kid === kid);
  if (!key) {
    throw new Error(`No matching key found for kid: ${kid}`);
  }
  return importJWK(key);
}
async function verifyIdToken(idToken, expectedNonce) {
  const { header, payload } = parseJWT(idToken);
  if (payload.iss !== WORLD_ID_ISSUER) {
    throw new Error(`Invalid issuer: ${payload.iss}`);
  }
  if (payload.aud !== WORLD_ID_APP_ID) {
    throw new Error(`Invalid audience: ${payload.aud}`);
  }
  if (payload.nonce !== expectedNonce) {
    throw new Error("Nonce mismatch");
  }
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) {
    throw new Error("Token expired");
  }
  const signingKey = await fetchSigningKey(header.kid);
  const valid = await verifyJWTSignature(idToken, signingKey);
  if (!valid) {
    throw new Error("Invalid token signature");
  }
  return payload;
}
function getRedirectURL() {
  return chrome.identity.getRedirectURL("/callback");
}
async function signIn() {
  const nonce = generateNonce();
  const state = generateState();
  const redirectUri = getRedirectURL();
  const params = new URLSearchParams({
    client_id: WORLD_ID_APP_ID,
    response_type: "id_token",
    redirect_uri: redirectUri,
    scope: "openid",
    state,
    nonce,
    response_mode: "fragment"
  });
  const authUrl = `${WORLD_ID_AUTHORIZE_URL}?${params.toString()}`;
  const responseUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true
    }, (callbackUrl) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!callbackUrl) {
        reject(new Error("No callback URL received"));
        return;
      }
      resolve(callbackUrl);
    });
  });
  const hashParams = new URLSearchParams(responseUrl.split("#")[1] || "");
  const returnedState = hashParams.get("state");
  if (returnedState !== state) {
    throw new Error("State mismatch — possible CSRF attack");
  }
  const idToken = hashParams.get("id_token");
  if (!idToken) {
    const error = hashParams.get("error");
    const errorDesc = hashParams.get("error_description");
    throw new Error(`Authentication failed: ${error || "no id_token"} — ${errorDesc || "unknown error"}`);
  }
  const payload = await verifyIdToken(idToken, nonce);
  const credential = {
    sub: payload.sub,
    verificationLevel: payload.verification_level || "unknown",
    authenticatedAt: Date.now(),
    idToken
  };
  await chrome.storage.local.set({ [STORAGE_KEY_AUTH]: credential });
  return credential;
}
async function signOut() {
  await chrome.storage.local.remove(STORAGE_KEY_AUTH);
}
async function getCredential() {
  const result = await chrome.storage.local.get(STORAGE_KEY_AUTH);
  return result[STORAGE_KEY_AUTH] || null;
}

// src/extension/popup.ts
var BACKEND_URL = "https://poc-backend.amdal-dev.workers.dev";
var authOverlay = document.getElementById("auth-overlay");
var authBtn = document.getElementById("auth-btn");
var skipBtn = document.getElementById("skip-btn");
var authErrorEl = document.getElementById("auth-error");
var authPill = document.getElementById("auth-pill");
var authDot = document.getElementById("auth-dot");
var authLabel = document.getElementById("auth-label");
var siteDomainEl = document.getElementById("site-domain");
var scoreArc = document.getElementById("score-arc");
var scoreValue = document.getElementById("score-value");
var trustSignals = document.getElementById("trust-signals");
var noData = document.getElementById("no-data");
var sigVisitors = document.getElementById("sig-visitors");
var sigRepeat = document.getElementById("sig-repeat");
var sigTime = document.getElementById("sig-time");
var myTime = document.getElementById("my-time");
var myVisits = document.getElementById("my-visits");
var mySince = document.getElementById("my-since");
var contributeToggle = document.getElementById("contribute-toggle");
var footerStat = document.getElementById("footer-stat");
var brregSection = document.getElementById("brreg-section");
var brregDetails = document.getElementById("brreg-details");
function formatTime(seconds) {
  if (seconds < 60)
    return `${seconds}s`;
  if (seconds < 3600)
    return `${Math.round(seconds / 60)}m`;
  const hours = Math.floor(seconds / 3600);
  const mins = Math.round(seconds % 3600 / 60);
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}
function formatDate(timestamp) {
  const d = new Date(timestamp);
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  return `${months[d.getMonth()]} ${d.getDate()}`;
}
function formatNumber(n) {
  if (n >= 1e6)
    return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1000)
    return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}
function extractDomain(url) {
  try {
    const parsed = new URL(url);
    if (["chrome:", "chrome-extension:", "about:", "edge:"].includes(parsed.protocol)) {
      return null;
    }
    return parsed.hostname;
  } catch {
    return null;
  }
}
function setScoreRing(score) {
  const circumference = 2 * Math.PI * 15;
  const filled = score / 100 * circumference;
  scoreArc.setAttribute("stroke-dasharray", `${filled} ${circumference}`);
  scoreValue.textContent = String(score);
  let color = "#f87171";
  if (score >= 70)
    color = "#4ade80";
  else if (score >= 40)
    color = "#facc15";
  scoreArc.setAttribute("stroke", color);
}
function showAuthState(credential) {
  if (credential) {
    authOverlay.classList.add("hidden");
    authPill.className = "auth-pill verified";
    authDot.className = "dot green";
    const level = credential.verificationLevel === "orb" ? "Orb verified" : credential.verificationLevel === "device" ? "Device verified" : "Verified";
    authLabel.textContent = level;
  } else {
    authPill.className = "auth-pill unverified";
    authDot.className = "dot gray";
    authLabel.textContent = "Not verified";
    authOverlay.classList.add("hidden");
  }
}
async function handleSignIn() {
  authBtn.textContent = "Verifying...";
  authBtn.disabled = true;
  authErrorEl.style.display = "none";
  try {
    const credential = await signIn();
    showAuthState(credential);
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    if (msg.includes("canceled") || msg.includes("cancelled") || msg.includes("user denied")) {} else {
      authErrorEl.textContent = msg;
      authErrorEl.style.display = "block";
    }
  } finally {
    authBtn.textContent = "Verify with World ID";
    authBtn.disabled = false;
  }
}
function handleSkip() {
  chrome.storage.local.set({ "auth:skipped": true });
  authOverlay.classList.add("hidden");
}
async function handleSignOut() {
  await signOut();
  await chrome.storage.local.remove("auth:skipped");
  showAuthState(null);
}
async function fetchSiteTrust(domain) {
  try {
    const res = await fetch(`${BACKEND_URL}/api/domain/${encodeURIComponent(domain)}`);
    if (!res.ok)
      return null;
    return await res.json();
  } catch {
    return null;
  }
}
function displaySiteTrust(stats) {
  if (!stats || stats.uniqueCommitments === 0) {
    trustSignals.style.display = "none";
    noData.style.display = "block";
    scoreValue.textContent = "--";
    scoreArc.setAttribute("stroke-dasharray", "0 94.2");
    return;
  }
  trustSignals.style.display = "grid";
  noData.style.display = "none";
  sigVisitors.textContent = formatNumber(stats.uniqueCommitments);
  const repeatRate = stats.totalVisits > stats.uniqueCommitments ? Math.round((stats.totalVisits - stats.uniqueCommitments) / stats.totalVisits * 100) : 0;
  sigRepeat.textContent = `${repeatRate}%`;
  const avgMin = stats.avgSeconds > 0 ? Math.round(stats.avgSeconds / 60) : 0;
  sigTime.textContent = avgMin > 0 ? `${avgMin}m` : "<1m";
  let score = 0;
  score += Math.min(stats.uniqueCommitments * 4, 40);
  score += Math.round(repeatRate * 0.35);
  score += Math.min(avgMin * 2.5, 25);
  score = Math.min(Math.round(score), 100);
  setScoreRing(score);
}
async function displayYourCommitment(domain) {
  const key = `visit:${domain}`;
  const result = await chrome.storage.local.get(key);
  const visit = result[key];
  if (visit) {
    myTime.textContent = formatTime(visit.totalSeconds);
    myVisits.textContent = String(visit.visitCount);
    mySince.textContent = formatDate(visit.firstSeen);
  } else {
    myTime.textContent = "0s";
    myVisits.textContent = "0";
    mySince.textContent = "Now";
  }
}
async function updateFooterStats() {
  const all = await chrome.storage.local.get(null);
  let siteCount = 0;
  for (const key of Object.keys(all)) {
    if (key.startsWith("visit:"))
      siteCount++;
  }
  footerStat.textContent = `${siteCount} site${siteCount !== 1 ? "s" : ""} tracked`;
}
async function initContributeToggle() {
  const result = await chrome.storage.local.get("config:contributing");
  const isContributing = result["config:contributing"] === true;
  contributeToggle.checked = isContributing;
  contributeToggle.addEventListener("change", () => {
    chrome.storage.local.set({ "config:contributing": contributeToggle.checked });
    chrome.runtime.sendMessage({ type: "contributing-changed", value: contributeToggle.checked });
  });
}
async function checkBrregData(domain) {
  const d = bare(domain);
  const { "shop:org": orgs = {} } = await chrome.storage.local.get("shop:org");
  const b = orgs[d] ? await chrome.runtime.sendMessage({ type: "commit-brreg", orgnr: orgs[d] }).catch(() => null) : null;
  if (!b) {
    brregSection.style.display = "none";
    return;
  }
  const l = brregLine(d, b);
  brregSection.style.display = "block";
  brregDetails.classList.add("visible");
  brregDetails.innerHTML = `${esc(l.text)}${l.red.map((r) => `<br/><b style="color:#f87171">${esc(r)}</b>`).join("")}<br/><span style="color:#8c959f">Org.nr ${esc(b.orgnr)} fra siden · Brønnøysundregistrene</span>`;
}
async function senderName() {
  const info = await new Promise((r) => chrome.identity?.getProfileUserInfo ? chrome.identity.getProfileUserInfo((i) => r(i)) : r({})).catch(() => ({}));
  const t = (info.email || "").split("@")[0].split(/[._+-]/)[0];
  return t ? t[0].toUpperCase() + t.slice(1) : "En venn";
}
async function renderCard() {
  const box = document.getElementById("card-section");
  const { "shop:log": log = {}, "card:hidden": hidden = [], "kort:imported": imported = [] } = await chrome.storage.local.get(["shop:log", "card:hidden", "kort:imported"]);
  const rows = cardRows(log).filter((r) => !hidden.includes(r.d));
  const fra = await senderName();
  const mine = rows.length ? rows.map((r) => `<div class="card-row"><span>${esc(friendLine("Du", r).replace(/^Du: /, r.d + ": "))}</span><button data-hide="${esc(r.d)}" title="Fjern fra kortet">✕</button></div>`).join("") + `<button id="card-copy" class="card-btn">Kopier lenke til kortet</button><div class="card-note">Sendes som «${esc(fra)}». Lenken inneholder bare radene over. Ingen server lagrer den.</div>` : `<div class="card-note">Tomt ennå. Kortet fylles lokalt med butikker (med org.nr) du kommer tilbake til over flere måneder, og ordrebekreftelser du når. Helse, apotek, spill, dating, bank og lån telles aldri.</div>`;
  const theirs = imported.length ? `<div class="card-sub">Kort fra venner</div>` + imported.map((c, i) => `<div class="card-row"><span>${esc(c.fra)} · ${c.rader.length} ${c.rader.length === 1 ? "butikk" : "butikker"}</span><button data-drop="${i}" title="Fjern kortet">✕</button></div>`).join("") : "";
  const { "shop:history": hist } = await chrome.storage.local.get("shop:history");
  const granted = await chrome.permissions.contains({ permissions: ["history"] }).catch(() => false);
  const nb = (t) => new Date(t).toLocaleDateString("nb-NO", { day: "2-digit", month: "2-digit", year: "numeric" });
  const histNote = hist && granted ? `<div class="card-note">Lest lokalt fra nettleserhistorikken ${nb(hist.from)}–${nb(hist.to)}: ${hist.touched} ${hist.touched === 1 ? "butikk" : "butikker"}. Regel: bare nettsteder med en ordrebekreftelse i historikken, eller der du har sett org.nr, telles. Ingenting sendes. <a href="#" id="hist-off">Slå av tilgangen</a></div>` : "";
  const histBtn = `<button id="hist-read" class="card-btn">${granted ? "Oppdater fra historikken (90 dager)" : `Lag kortet fra de siste ${HISTORY_DAYS} dagene`}</button>`;
  box.innerHTML = `<div class="card-sub">Mitt kort</div>${mine}${histBtn}${histNote}${theirs}`;
  box.querySelector("#hist-read").addEventListener("click", async () => {
    const ok = await chrome.permissions.request({ permissions: ["history"] }).catch(() => false);
    if (!ok)
      return;
    await chrome.runtime.sendMessage({ type: "commit-history-read" }).catch(() => null);
    renderCard();
  });
  box.querySelector("#hist-off")?.addEventListener("click", async (e) => {
    e.preventDefault();
    await chrome.permissions.remove({ permissions: ["history"] }).catch(() => false);
    await chrome.storage.local.remove("shop:history");
    renderCard();
  });
  box.querySelectorAll("[data-hide]").forEach((btn) => btn.addEventListener("click", async () => {
    await chrome.storage.local.set({ "card:hidden": [...hidden, btn.dataset.hide] });
    renderCard();
  }));
  box.querySelectorAll("[data-drop]").forEach((btn) => btn.addEventListener("click", async () => {
    await chrome.storage.local.set({ "kort:imported": imported.filter((_, i) => i !== Number(btn.dataset.drop)) });
    renderCard();
  }));
  box.querySelector("#card-copy")?.addEventListener("click", async () => {
    const link = `https://getcommit.dev/extension#kort=${encodeCard({ v: 1, fra, laget: new Date().toISOString().slice(0, 10), rader: rows })}`;
    await navigator.clipboard.writeText(link).catch(() => {});
    const b = box.querySelector("#card-copy");
    b.textContent = "Kopiert. Lim inn i en melding til en venn.";
    b.dataset.link = link;
  });
}
renderCard();
authPill.addEventListener("click", async () => {
  const credential = await getCredential();
  if (credential) {
    if (confirm("Sign out of Commit?")) {
      await handleSignOut();
    }
  } else {
    authOverlay.classList.remove("hidden");
  }
});
authBtn.addEventListener("click", handleSignIn);
skipBtn.addEventListener("click", handleSkip);
async function init() {
  const credential = await getCredential();
  showAuthState(credential);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const domain = tab?.url ? extractDomain(tab.url) : null;
  if (domain) {
    siteDomainEl.textContent = domain;
    const { "config:contributing": optIn } = await chrome.storage.local.get("config:contributing");
    const [siteStats] = await Promise.all([
      optIn === true ? fetchSiteTrust(domain) : Promise.resolve(null),
      displayYourCommitment(domain)
    ]);
    displaySiteTrust(siteStats);
    checkBrregData(domain);
  } else {
    siteDomainEl.textContent = "No site";
    trustSignals.style.display = "none";
    noData.style.display = "block";
    noData.textContent = "Navigate to a website to see trust data.";
    myTime.textContent = "--";
    myVisits.textContent = "--";
    mySince.textContent = "--";
  }
  await Promise.all([
    updateFooterStats(),
    initContributeToggle()
  ]);
}
init();
