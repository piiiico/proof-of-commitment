// src/extension/shop.ts
var bare = (h) => h.toLowerCase().replace(/^www\./, "");
var SENSITIVE_DOMAIN = /(apotek|pharma|farmasi|vitusapotek|boots|helse|klinikk|legesenter|tannlege|psykolog|casino|poker|bet(t|ting)?\b|bet\.|odds|spill|tipping|lotto|dating|tinder|match\.|happn|porn|xxx|sex|onlyfans|escort|kirke|church|moske|parti\b|partiet|bank|kreditt|credit|lan\.|forbruksl|refinans|forsikring)/i;
var SENSITIVE_NACE = /^(64|65|66|86|87|88|92|94)\.|^47\.7[34]/;
var sensitive = (domain, nace) => SENSITIVE_DOMAIN.test(domain) || !!nace && SENSITIVE_NACE.test(nace);
var ORDER_PATH = /(checkout\/(success|complete|confirmation|thank)|order[-_/]?(confirmation|received|complete|success)|ordrebekreftelse|kvittering|bestilling\/(takk|fullfort|bekreftelse)|\/takk(-for-(din-)?(bestilling|handelen|ordren|kjopet))?(\/|$|\?)|\/thank-?you(\/|$|\?))/i;
var ORDER_TEXT = /(takk for (din |di )?(bestilling|ordre|handelen|kjøpet)|ordrebekreftelse|din ordre er (mottatt|bekreftet|registrert)|bestillingen (din )?er mottatt|thank you for your (order|purchase)|order (confirmed|received))/i;
function isOrderPage(path, headline) {
  return ORDER_PATH.test(path) || ORDER_TEXT.test(headline);
}
var STOP = new Set(["as", "asa", "ab", "aps", "norge", "norway", "norden", "nordic", "scandinavia", "group", "holding", "drift", "handel", "og", "the", "ltd", "gmbh", "sa", "nuf", "da", "ans", "ba", "sa"]);
var HISTORY_DAYS = 90;
function monthWindows(now, days = HISTORY_DAYS) {
  const from = now - days * 86400000, out = [];
  let d = new Date(from);
  while (d.getTime() < now) {
    const next = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1));
    out.push({ start: d.getTime(), end: Math.min(next.getTime(), now), m: d.toISOString().slice(0, 7) });
    d = next;
  }
  return out;
}
function mergeHistory(log, items, orgs) {
  const per = {};
  for (const it of items) {
    let u;
    try {
      u = new URL(it.url);
    } catch {
      continue;
    }
    if (u.protocol !== "https:" && u.protocol !== "http:")
      continue;
    const d = bare(u.hostname);
    const day = new Date(it.t).toISOString().slice(0, 10);
    const p = per[d] ||= { months: new Set, orders: new Set };
    p.months.add(day.slice(0, 7));
    if (isOrderPage(u.pathname, it.title || ""))
      p.orders.add(day + u.pathname);
  }
  const out = { ...log }, touched = [];
  for (const [d, p] of Object.entries(per)) {
    if (sensitive(d, log[d]?.nace))
      continue;
    if (p.orders.size === 0 && !orgs[d])
      continue;
    const l = log[d] || { months: [], orders: [] };
    out[d] = { ...l, months: [...new Set([...l.months, ...p.months])].sort(), orders: [...new Set([...l.orders, ...p.orders])].sort() };
    touched.push(d);
  }
  return { log: out, touched: touched.sort() };
}

// src/extension/background.ts
var STORAGE_KEY_CONFIG = "config:backendUrl";
var STORAGE_KEY_QUEUE = "sync:queue";
var SYNC_ALARM_NAME = "poc-sync";
var SYNC_INTERVAL_MINUTES = 5;
var DEFAULT_BACKEND_URL = "https://poc-backend.amdal-dev.workers.dev";
var activeTabDomain = null;
var activeTabStart = Date.now();
function extractDomain(url) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol === "chrome:" || parsed.protocol === "chrome-extension:" || parsed.protocol === "about:") {
      return null;
    }
    return parsed.hostname;
  } catch {
    return null;
  }
}
async function switchDomain(newDomain) {
  const now = Date.now();
  if (activeTabDomain) {
    const elapsed = Math.round((now - activeTabStart) / 1000);
    if (elapsed > 0) {
      await recordVisit(activeTabDomain, elapsed);
    }
  }
  activeTabDomain = newDomain;
  activeTabStart = now;
}
async function recordVisit(domain, seconds) {
  const key = `visit:${domain}`;
  const now = Date.now();
  const result = await chrome.storage.local.get([key, STORAGE_KEY_QUEUE]);
  const existing = result[key] ?? {
    domain,
    firstSeen: now,
    lastSeen: 0,
    totalSeconds: 0,
    visitCount: 0
  };
  existing.lastSeen = now;
  existing.totalSeconds += seconds;
  existing.visitCount += 1;
  const queue = result[STORAGE_KEY_QUEUE] ?? [];
  queue.push({
    domain,
    visitCount: 1,
    totalSeconds: seconds,
    firstSeen: now,
    lastSeen: now
  });
  await chrome.storage.local.set({
    [key]: existing,
    [STORAGE_KEY_QUEUE]: queue
  });
}
async function getBackendUrl() {
  const result = await chrome.storage.local.get(STORAGE_KEY_CONFIG);
  return result[STORAGE_KEY_CONFIG] ?? DEFAULT_BACKEND_URL;
}
async function isContributing() {
  const result = await chrome.storage.local.get("config:contributing");
  return result["config:contributing"] === true;
}
async function flushSyncQueue() {
  if (!await isContributing()) {
    console.log("[Commit] Contributing disabled — skipping sync");
    return;
  }
  const backendUrl = await getBackendUrl();
  const result = await chrome.storage.local.get(STORAGE_KEY_QUEUE);
  const queue = result[STORAGE_KEY_QUEUE] ?? [];
  if (queue.length === 0)
    return;
  try {
    const res = await fetch(`${backendUrl}/api/commit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(queue)
    });
    if (res.ok) {
      const afterResult = await chrome.storage.local.get(STORAGE_KEY_QUEUE);
      const afterQueue = afterResult[STORAGE_KEY_QUEUE] ?? [];
      const remaining = afterQueue.slice(queue.length);
      await chrome.storage.local.set({ [STORAGE_KEY_QUEUE]: remaining });
      console.log(`[Commit] Synced ${queue.length} commitments to backend`);
    } else {
      console.warn(`[Commit] Backend sync failed: HTTP ${res.status} — will retry`);
    }
  } catch (err) {
    console.warn("[Commit] Backend unreachable — queued for next sync:", err);
  }
}
async function setupSyncAlarm() {
  const existing = await chrome.alarms.get(SYNC_ALARM_NAME);
  if (!existing) {
    chrome.alarms.create(SYNC_ALARM_NAME, {
      periodInMinutes: SYNC_INTERVAL_MINUTES
    });
    console.log(`[Commit] Sync alarm set: every ${SYNC_INTERVAL_MINUTES} minutes`);
  }
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SYNC_ALARM_NAME) {
    await flushSyncQueue();
  }
});
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    const domain = tab.url ? extractDomain(tab.url) : null;
    await switchDomain(domain);
  } catch {
    await switchDomain(null);
  }
});
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url && tab.active) {
    const domain = extractDomain(changeInfo.url);
    await switchDomain(domain);
  }
});
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await switchDomain(null);
  } else {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        windowId
      });
      const domain = tab?.url ? extractDomain(tab.url) : null;
      await switchDomain(domain);
    } catch {
      await switchDomain(null);
    }
  }
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes["auth:credential"]) {
    const newValue = changes["auth:credential"].newValue;
    if (newValue) {
      console.log("[Commit] User authenticated:", newValue.verificationLevel);
      flushSyncQueue().catch(console.warn);
    } else {
      console.log("[Commit] User signed out");
    }
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "contributing-changed") {
    console.log("[Commit] Contributing toggled:", message.value);
    if (message.value) {
      flushSyncQueue().catch(console.warn);
    }
    sendResponse({ ok: true });
  }
  if (message.type === "commit-history-read") {
    readHistory().then(sendResponse, () => sendResponse(null));
    return true;
  }
  if (message.type === "commit-brreg") {
    lookupBrreg(String(message.orgnr)).then(sendResponse, () => sendResponse(null));
    return true;
  }
});
var BRREG_TTL = 7 * 86400000;
async function lookupBrreg(orgnr) {
  if (!/^\d{9}$/.test(orgnr))
    return null;
  const { "brreg:cache": cache = {} } = await chrome.storage.local.get("brreg:cache");
  if (cache[orgnr] && Date.now() - cache[orgnr].t < BRREG_TTL)
    return cache[orgnr].b;
  const get = async (u) => {
    const r = await fetch(u);
    return r.ok ? r.json() : null;
  };
  let e = await get(`https://data.brreg.no/enhetsregisteret/api/enheter/${orgnr}`);
  if (!e) {
    const u = await get(`https://data.brreg.no/enhetsregisteret/api/underenheter/${orgnr}`);
    if (u?.overordnetEnhet)
      e = await get(`https://data.brreg.no/enhetsregisteret/api/enheter/${u.overordnetEnhet}`);
  }
  if (!e)
    return null;
  let omsetning = null, aar = null;
  const rs = await get(`https://data.brreg.no/regnskapsregisteret/regnskap/${e.organisasjonsnummer}`).catch(() => null);
  if (Array.isArray(rs) && rs.length) {
    const r = [...rs].sort((a, b2) => String(b2.regnskapsperiode?.tilDato).localeCompare(String(a.regnskapsperiode?.tilDato)))[0];
    const v = r?.resultatregnskapResultat?.driftsresultat?.driftsinntekter?.sumDriftsinntekter;
    if (typeof v === "number") {
      omsetning = v;
      aar = String(r.regnskapsperiode.tilDato).slice(0, 4);
    }
  }
  const b = {
    orgnr: e.organisasjonsnummer,
    navn: e.navn,
    start: e.stiftelsesdato || e.registreringsdatoEnhetsregisteret || null,
    ansatte: e.harRegistrertAntallAnsatte ? e.antallAnsatte : null,
    nace: e.naeringskode1?.kode || null,
    konkurs: !!e.konkurs,
    avvikling: !!e.underAvvikling,
    tvang: !!e.underTvangsavviklingEllerTvangsopplosning,
    slettet: !!e.slettedato,
    omsetning,
    aar,
    hjemmeside: e.hjemmeside || null
  };
  cache[orgnr] = { t: Date.now(), b };
  await chrome.storage.local.set({ "brreg:cache": cache });
  return b;
}
async function readHistory() {
  if (!await chrome.permissions.contains({ permissions: ["history"] }))
    return null;
  const now = Date.now(), items = [];
  for (const w of monthWindows(now)) {
    const r = await chrome.history.search({ text: "", startTime: w.start, endTime: w.end, maxResults: 1e5 });
    for (const h of r)
      if (h.url && h.lastVisitTime)
        items.push({ url: h.url, title: h.title, t: Math.min(Math.max(h.lastVisitTime, w.start), w.end - 1) });
  }
  const { "shop:log": log = {}, "shop:org": orgs = {} } = await chrome.storage.local.get(["shop:log", "shop:org"]);
  const m = mergeHistory(log, items, orgs);
  const hist = { from: now - HISTORY_DAYS * 86400000, to: now, touched: m.touched.length };
  await chrome.storage.local.set({ "shop:log": m.log, "shop:history": hist });
  return hist;
}
chrome.permissions.onAdded.addListener((p) => {
  if (p.permissions?.includes("history"))
    readHistory().catch(() => {});
});
async function init() {
  await setupSyncAlarm();
  await flushSyncQueue();
}
init().catch(console.error);
console.log("[Commit] Background service worker started");
