// src/extension/auth.ts
var WORLD_ID_APP_ID = "app_a2868bad17534bb7e8bc82de8df73773";
var WORLD_ID_AUTHORIZE_URL = "https://id.worldcoin.org/authorize";
var WORLD_ID_JWKS_URL = "https://id.worldcoin.org/jwks.json";
var WORLD_ID_ISSUER = "https://id.worldcoin.org";
var STORAGE_KEY_AUTH = "auth:credential";
function generateNonce() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(16).padStart(2, "0")).join("");
}
function generateState() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(16).padStart(2, "0")).join("");
}
function base64urlDecode(str) {
  let base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4 !== 0) {
    base64 += "=";
  }
  return atob(base64);
}
function parseJWT(token) {
  const parts = token.split(".");
  if (parts.length !== 3)
    throw new Error("Invalid JWT format");
  const header = JSON.parse(base64urlDecode(parts[0]));
  const payload = JSON.parse(base64urlDecode(parts[1]));
  return { header, payload };
}
async function importJWK(jwk) {
  return crypto.subtle.importKey("jwk", {
    kty: jwk.kty,
    n: jwk.n,
    e: jwk.e,
    alg: jwk.alg,
    use: jwk.use
  }, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
}
async function verifyJWTSignature(token, key) {
  const parts = token.split(".");
  const signedContent = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
  const signatureStr = parts[2].replace(/-/g, "+").replace(/_/g, "/");
  const paddedSig = signatureStr + "=".repeat((4 - signatureStr.length % 4) % 4);
  const signatureBytes = Uint8Array.from(atob(paddedSig), (c) => c.charCodeAt(0));
  return crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, signatureBytes, signedContent);
}
async function fetchSigningKey(kid) {
  const response = await fetch(WORLD_ID_JWKS_URL);
  if (!response.ok) {
    throw new Error(`Failed to fetch JWKS: ${response.status}`);
  }
  const jwks = await response.json();
  const key = jwks.keys.find((k) => k.kid === kid);
  if (!key) {
    throw new Error(`No matching key found for kid: ${kid}`);
  }
  return importJWK(key);
}
async function verifyIdToken(idToken, expectedNonce) {
  const { header, payload } = parseJWT(idToken);
  if (payload.iss !== WORLD_ID_ISSUER) {
    throw new Error(`Invalid issuer: ${payload.iss}`);
  }
  if (payload.aud !== WORLD_ID_APP_ID) {
    throw new Error(`Invalid audience: ${payload.aud}`);
  }
  if (payload.nonce !== expectedNonce) {
    throw new Error("Nonce mismatch");
  }
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) {
    throw new Error("Token expired");
  }
  const signingKey = await fetchSigningKey(header.kid);
  const valid = await verifyJWTSignature(idToken, signingKey);
  if (!valid) {
    throw new Error("Invalid token signature");
  }
  return payload;
}
function getRedirectURL() {
  return chrome.identity.getRedirectURL("/callback");
}
async function signIn() {
  const nonce = generateNonce();
  const state = generateState();
  const redirectUri = getRedirectURL();
  const params = new URLSearchParams({
    client_id: WORLD_ID_APP_ID,
    response_type: "id_token",
    redirect_uri: redirectUri,
    scope: "openid",
    state,
    nonce,
    response_mode: "fragment"
  });
  const authUrl = `${WORLD_ID_AUTHORIZE_URL}?${params.toString()}`;
  const responseUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true
    }, (callbackUrl) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!callbackUrl) {
        reject(new Error("No callback URL received"));
        return;
      }
      resolve(callbackUrl);
    });
  });
  const hashParams = new URLSearchParams(responseUrl.split("#")[1] || "");
  const returnedState = hashParams.get("state");
  if (returnedState !== state) {
    throw new Error("State mismatch — possible CSRF attack");
  }
  const idToken = hashParams.get("id_token");
  if (!idToken) {
    const error = hashParams.get("error");
    const errorDesc = hashParams.get("error_description");
    throw new Error(`Authentication failed: ${error || "no id_token"} — ${errorDesc || "unknown error"}`);
  }
  const payload = await verifyIdToken(idToken, nonce);
  const credential = {
    sub: payload.sub,
    verificationLevel: payload.verification_level || "unknown",
    authenticatedAt: Date.now(),
    idToken
  };
  await chrome.storage.local.set({ [STORAGE_KEY_AUTH]: credential });
  return credential;
}
async function getCredential() {
  const result = await chrome.storage.local.get(STORAGE_KEY_AUTH);
  return result[STORAGE_KEY_AUTH] || null;
}

// src/extension/overlay.ts
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
var host = (u) => {
  try {
    return new URL(u).hostname.toLowerCase().replace(/^www\./, "");
  } catch {
    return "";
  }
};
var VERDICT = { again: "ville kjøpt igjen", use: "bruker", avoid: "ville unngått" };
function line(e) {
  const who = [e.name, e.field || e.evidence].filter(Boolean).join(", ");
  const what = [e.item, e.brand].filter(Boolean).join(" ");
  return `${who}: ${what}${e.place ? ` hos ${e.place}` : ""} — ${VERDICT[e.verdict] || e.verdict}${e.why ? `. «${e.why}»` : ""} (${e.date})`;
}
function isGoogleSerp() {
  return /(^|\.)google\.[a-z.]+$/.test(location.hostname) && location.pathname === "/search";
}
function chip(site) {
  const el = document.createElement("div");
  el.className = "commit-overlay";
  el.style.cssText = "font:12px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;margin:4px 0 8px;color:#5f6368";
  const rows = site.endorsements.slice(0, 3).map((e) => `<div style="padding:4px 8px;border-left:3px solid ${e.verdict === "avoid" ? "#d93025" : "#188038"};background:#f8f9fa;margin-top:2px;color:#202124"><b>Fra nettverket ditt</b> · ${esc(line(e))}</div>`).join("");
  const time = site.registered ? `<span title="Registreringsdato i RDAP (domeneregisteret)">Domene registrert ${esc(site.registered)}</span>` : "";
  if (!rows && !time)
    return null;
  el.innerHTML = rows + (time ? `<div style="margin-top:2px">${time} · <a href="https://getcommit.dev/extension" style="color:#5f6368">Commit</a></div>` : "");
  return el;
}
async function serp() {
  const pick = (sel) => [...document.querySelectorAll(sel)].filter((a) => a.querySelector("h3"));
  const links = pick("#search a[href^='http'], #rso a[href^='http']").length ? pick("#search a[href^='http'], #rso a[href^='http']") : pick("a[href^='http']");
  const byDomain = new Map;
  for (const a of links) {
    const d = host(a.href);
    if (!d || /(^|\.)google\./.test(d))
      continue;
    byDomain.set(d, [...byDomain.get(d) || [], a]);
  }
  if (!byDomain.size)
    return;
  const res = await chrome.runtime.sendMessage({ type: "commit-sites", domains: [...byDomain.keys()].slice(0, 20) }).catch(() => null);
  const sites = res?.sites;
  if (!sites)
    return;
  for (const [d, anchors] of byDomain) {
    const s = sites[d];
    if (!s)
      continue;
    const a = anchors[0];
    if (a.parentElement?.querySelector(":scope > .commit-overlay"))
      continue;
    const c = chip(s);
    if (c)
      a.parentElement?.appendChild(c);
  }
}
async function shopBadge() {
  const d = location.hostname.toLowerCase().replace(/^www\./, "");
  const { "overlay:seen": seen } = await chrome.storage.local.get("overlay:seen");
  const s = seen?.[d];
  if (!s?.endorsements?.length || document.getElementById("commit-anbefal-badge"))
    return;
  const b = document.createElement("div");
  b.id = "commit-anbefal-badge";
  b.style.cssText = "position:fixed;bottom:16px;right:16px;z-index:2147483647;max-width:360px;padding:10px 12px;background:#fff;border:1px solid #dadce0;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,.15);font:13px/1.45 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#202124;cursor:pointer";
  b.title = "Klikk for å lukke";
  b.innerHTML = `<b>Fra nettverket ditt</b>${s.endorsements.slice(0, 3).map((e) => `<div style="margin-top:4px">${esc(line(e))}</div>`).join("")}`;
  b.addEventListener("click", () => b.remove());
  document.body.appendChild(b);
}
async function connectBar() {
  const m = location.pathname.match(/^\/anbefal\/i\/([a-z0-9]{6,20})$/);
  if (!m)
    return;
  const code = m[1];
  const { "overlay:code": cur } = await chrome.storage.local.get("overlay:code");
  const bar = document.createElement("div");
  bar.id = "commit-connect-bar";
  bar.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;padding:10px 16px;background:#202124;color:#fff;font:14px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;display:flex;gap:12px;align-items:center;justify-content:center";
  const render = (on) => {
    bar.innerHTML = on ? `Commit-utvidelsen viser anbefalingene fra nettverket ditt i Google-søk. <button id="commit-off">Slå av</button>` : `Vis anbefalingene fra nettverket ditt i Google-søk? Bare domenene i søkeresultatene sendes, ingen historikk. <button id="commit-on">Slå på</button> <a href="https://getcommit.dev/extension#personvern" style="color:#8ab4f8">Personvern</a>`;
    bar.querySelector("#commit-on")?.addEventListener("click", async () => {
      await chrome.storage.local.set({ "overlay:code": code });
      render(true);
    });
    bar.querySelector("#commit-off")?.addEventListener("click", async () => {
      await chrome.storage.local.remove(["overlay:code", "overlay:seen"]);
      render(false);
    });
  };
  render(cur === code);
  document.body.appendChild(bar);
}
async function initOverlay() {
  if (location.hostname === "getcommit.dev")
    return connectBar();
  const { "overlay:code": code } = await chrome.storage.local.get("overlay:code");
  if (!code)
    return;
  if (isGoogleSerp())
    return serp();
  return shopBadge();
}

// src/extension/content.ts
var BACKEND_URL = "https://poc-backend.amdal-dev.workers.dev";
function extractGitHubRepo() {
  const match = window.location.pathname.match(/^\/([^/]+)\/([^/]+)/);
  if (!match)
    return null;
  const owner = match[1];
  const repo = match[2];
  if (["features", "pricing", "about", "orgs", "settings", "login", "join"].includes(owner)) {
    return null;
  }
  if (repo.startsWith(".") || owner.startsWith("."))
    return null;
  return { owner, repo };
}
async function fetchGitHubTrust(owner, repo) {
  try {
    const res = await fetch(`${BACKEND_URL}/api/github/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`);
    if (!res.ok)
      return null;
    return await res.json();
  } catch {
    return null;
  }
}
function scoreColor(score) {
  if (score >= 70)
    return "#4ade80";
  if (score >= 45)
    return "#facc15";
  return "#f87171";
}
function formatAge(years) {
  if (years < 0.1)
    return "< 1 month";
  if (years < 1)
    return `${Math.round(years * 12)} months`;
  const y = Math.floor(years);
  const m = Math.round((years - y) * 12);
  if (m === 0)
    return `${y} yr`;
  return `${y} yr ${m} mo`;
}
function injectGitHubPanel(data) {
  if (document.getElementById("commit-gh-panel"))
    return;
  const color = scoreColor(data.score);
  const circumference = 2 * Math.PI * 30;
  const filled = data.score / 100 * circumference;
  const sidebar = document.querySelector(".Layout-sidebar") ?? document.querySelector('[data-target="repos-header.sidebar"]') ?? document.querySelector(".repository-lang-stats-graph")?.parentElement ?? null;
  const panel = document.createElement("div");
  panel.id = "commit-gh-panel";
  panel.style.cssText = `
    background: #f6f8fa;
    border: 1px solid #d0d7de;
    border-radius: 6px;
    padding: 16px;
    margin-bottom: 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    font-size: 12px;
    color: #24292f;
  `;
  panel.innerHTML = `
    <style>
      #commit-gh-panel .commit-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 12px;
      }
      #commit-gh-panel .commit-brand {
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.8px;
        text-transform: uppercase;
        color: #656d76;
      }
      #commit-gh-panel .commit-score-row {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 12px;
      }
      #commit-gh-panel .commit-score-ring {
        position: relative;
        width: 56px;
        height: 56px;
        flex-shrink: 0;
      }
      #commit-gh-panel .commit-score-ring svg {
        transform: rotate(-90deg);
      }
      #commit-gh-panel .commit-score-number {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        font-weight: 700;
        color: #24292f;
      }
      #commit-gh-panel .commit-score-label {
        font-size: 11px;
        color: #656d76;
        line-height: 1.4;
      }
      #commit-gh-panel .commit-signals {
        border-top: 1px solid #d0d7de;
        padding-top: 10px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 6px 12px;
        margin-bottom: 12px;
      }
      #commit-gh-panel .commit-signal {
        display: flex;
        justify-content: space-between;
        font-size: 11px;
      }
      #commit-gh-panel .commit-signal-key {
        color: #656d76;
      }
      #commit-gh-panel .commit-signal-val {
        font-weight: 600;
        color: #24292f;
        font-variant-numeric: tabular-nums;
      }
      #commit-gh-panel .commit-endorse-btn {
        display: block;
        width: 100%;
        padding: 6px 12px;
        background: #24292f;
        color: #fff;
        border: none;
        border-radius: 6px;
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
        text-decoration: none;
        box-sizing: border-box;
      }
      #commit-gh-panel .commit-endorse-btn:hover {
        background: #444c56;
      }
      #commit-gh-panel .commit-footer {
        margin-top: 8px;
        font-size: 10px;
        color: #8c959f;
        text-align: center;
      }
      #commit-gh-panel .commit-footer a {
        color: #8c959f;
        text-decoration: none;
      }
      #commit-gh-panel .commit-footer a:hover { text-decoration: underline; }
    </style>

    <div class="commit-header">
      <span class="commit-brand">Commit Score</span>
    </div>

    <div class="commit-score-row">
      <div class="commit-score-ring">
        <svg width="56" height="56" viewBox="0 0 56 56">
          <circle cx="28" cy="28" r="22" fill="none" stroke="#e5e7eb" stroke-width="5"/>
          <circle cx="28" cy="28" r="22" fill="none" stroke="${color}" stroke-width="5"
            stroke-linecap="round"
            stroke-dasharray="${data.score / 100 * (2 * Math.PI * 22).toFixed(4)} ${(2 * Math.PI * 22).toFixed(4)}"
          />
        </svg>
        <span class="commit-score-number">${data.score}</span>
      </div>
      <div class="commit-score-label">
        <strong>${data.score >= 70 ? "Healthy" : data.score >= 45 ? "Moderate" : "Early stage"}</strong><br/>
        Behavioral trust score
      </div>
    </div>

    <div class="commit-signals">
      <div class="commit-signal">
        <span class="commit-signal-key">Age</span>
        <span class="commit-signal-val">${formatAge(data.signals.ageYears)}</span>
      </div>
      <div class="commit-signal">
        <span class="commit-signal-key">Contributors</span>
        <span class="commit-signal-val">${data.signals.contributors}</span>
      </div>
      <div class="commit-signal">
        <span class="commit-signal-key">Stars</span>
        <span class="commit-signal-val">${data.signals.stars.toLocaleString()}</span>
      </div>
      <div class="commit-signal">
        <span class="commit-signal-key">Commits (30d)</span>
        <span class="commit-signal-val">${data.signals.recentCommits30d}</span>
      </div>
      <div class="commit-signal">
        <span class="commit-signal-key">Endorsements</span>
        <span class="commit-signal-val" id="commit-endorsement-count">${data.endorsements > 0 ? data.endorsements : "None yet"}</span>
      </div>
    </div>

    <button class="commit-endorse-btn" id="commit-endorse-btn">
      Endorse this repo →
    </button>

    <div class="commit-footer">
      <a href="https://getcommit.dev" target="_blank" rel="noopener">getcommit.dev</a>
      · behavioral trust, not stars
    </div>
  `;
  if (sidebar) {
    sidebar.insertBefore(panel, sidebar.firstChild);
  } else {
    const repoHeader = document.querySelector("#repository-container-header") ?? document.querySelector(".repohead") ?? document.querySelector("main > div:first-child");
    if (repoHeader?.parentElement) {
      repoHeader.parentElement.insertBefore(panel, repoHeader.nextSibling);
    } else {
      panel.style.cssText = "position:fixed;top:72px;right:16px;width:300px;z-index:2147483647";
      document.body.appendChild(panel);
    }
  }
  const endorseBtn = panel.querySelector("#commit-endorse-btn");
  if (endorseBtn) {
    endorseBtn.addEventListener("click", async () => {
      endorseBtn.disabled = true;
      endorseBtn.textContent = "Endorsing…";
      try {
        let cred = await getCredential();
        if (!cred) {
          cred = await signIn();
        }
        const res = await fetch(`${BACKEND_URL}/api/repos/${encodeURIComponent(data.owner)}/${encodeURIComponent(data.repo)}/endorse`, { method: "POST", headers: { Authorization: `Bearer ${cred.idToken}` } });
        if (res.ok) {
          const json = await res.json();
          endorseBtn.textContent = json.alreadyEndorsed ? "Already endorsed ✓" : "Endorsed ✓";
          const countEl = document.getElementById("commit-endorsement-count");
          if (countEl)
            countEl.textContent = json.endorsements.toString();
        } else {
          endorseBtn.textContent = "Failed — try again";
          endorseBtn.disabled = false;
        }
      } catch {
        endorseBtn.textContent = "Failed — try again";
        endorseBtn.disabled = false;
      }
    });
  }
}
async function fetchDomainStats(domain) {
  try {
    const res = await fetch(`${BACKEND_URL}/api/domain/${encodeURIComponent(domain)}`);
    if (!res.ok)
      return null;
    return await res.json();
  } catch {
    return null;
  }
}
function injectTrustBadge(stats) {
  if (document.getElementById("commit-trust-badge"))
    return;
  const repeatRate = stats.totalVisits > stats.uniqueCommitments ? Math.round((stats.totalVisits - stats.uniqueCommitments) / stats.totalVisits * 100) : 0;
  let color = "#f87171";
  let bg = "rgba(248, 113, 113, 0.1)";
  if (repeatRate >= 50 && stats.uniqueCommitments >= 5) {
    color = "#4ade80";
    bg = "rgba(74, 222, 128, 0.1)";
  } else if (repeatRate >= 25 || stats.uniqueCommitments >= 3) {
    color = "#facc15";
    bg = "rgba(250, 204, 21, 0.1)";
  }
  const badge = document.createElement("div");
  badge.id = "commit-trust-badge";
  badge.innerHTML = `
    <style>
      #commit-trust-badge {
        position: fixed;
        bottom: 16px;
        right: 16px;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        background: ${bg};
        backdrop-filter: blur(12px);
        border: 1px solid ${color}33;
        border-radius: 20px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 12px;
        color: ${color};
        cursor: pointer;
        transition: opacity 0.3s, transform 0.3s;
        opacity: 0.7;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      }
      #commit-trust-badge:hover { opacity: 1; transform: scale(1.05); }
      #commit-trust-badge .commit-dot {
        width: 6px; height: 6px; border-radius: 50%; background: ${color};
      }
      #commit-trust-badge.commit-dismissed {
        opacity: 0; pointer-events: none; transform: translateY(10px);
      }
    </style>
    <span class="commit-dot"></span>
    <span>${stats.uniqueCommitments} verified visitor${stats.uniqueCommitments !== 1 ? "s" : ""}</span>
  `;
  badge.addEventListener("click", () => {
    badge.classList.add("commit-dismissed");
    setTimeout(() => badge.remove(), 300);
  });
  document.body.appendChild(badge);
}
async function init() {
  const result = await chrome.storage.local.get("config:contributing");
  const contributing = result["config:contributing"] === true;
  const protocol = window.location.protocol;
  if (["chrome:", "chrome-extension:", "about:"].some((p) => protocol === p))
    return;
  const hostname = window.location.hostname;
  if (hostname === "github.com") {
    const ghRepo = extractGitHubRepo();
    if (ghRepo) {
      const data = await fetchGitHubTrust(ghRepo.owner, ghRepo.repo);
      if (data) {
        injectGitHubPanel(data);
      }
    }
    return;
  }
  if (!contributing)
    return;
  const stats = await fetchDomainStats(hostname);
  if (stats && stats.uniqueCommitments > 0) {
    injectTrustBadge(stats);
  }
}
setTimeout(init, 1500);
initOverlay().catch(() => {});
if (window.location.hostname === "github.com") {
  let lastPath = window.location.pathname;
  const observer = new MutationObserver(() => {
    if (window.location.pathname !== lastPath) {
      lastPath = window.location.pathname;
      document.getElementById("commit-gh-panel")?.remove();
      setTimeout(init, 800);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}
