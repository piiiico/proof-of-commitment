// src/extension/background.ts
var STORAGE_KEY_CONFIG = "config:backendUrl";
var STORAGE_KEY_QUEUE = "sync:queue";
var SYNC_ALARM_NAME = "poc-sync";
var SYNC_INTERVAL_MINUTES = 5;
var DEFAULT_BACKEND_URL = "https://poc-backend.amdal-dev.workers.dev";
var activeTabDomain = null;
var activeTabStart = Date.now();
function extractDomain(url) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol === "chrome:" || parsed.protocol === "chrome-extension:" || parsed.protocol === "about:") {
      return null;
    }
    return parsed.hostname;
  } catch {
    return null;
  }
}
async function switchDomain(newDomain) {
  const now = Date.now();
  if (activeTabDomain) {
    const elapsed = Math.round((now - activeTabStart) / 1000);
    if (elapsed > 0) {
      await recordVisit(activeTabDomain, elapsed);
    }
  }
  activeTabDomain = newDomain;
  activeTabStart = now;
}
async function recordVisit(domain, seconds) {
  const key = `visit:${domain}`;
  const now = Date.now();
  const result = await chrome.storage.local.get([key, STORAGE_KEY_QUEUE]);
  const existing = result[key] ?? {
    domain,
    firstSeen: now,
    lastSeen: 0,
    totalSeconds: 0,
    visitCount: 0
  };
  existing.lastSeen = now;
  existing.totalSeconds += seconds;
  existing.visitCount += 1;
  const queue = result[STORAGE_KEY_QUEUE] ?? [];
  queue.push({
    domain,
    visitCount: 1,
    totalSeconds: seconds,
    firstSeen: now,
    lastSeen: now
  });
  await chrome.storage.local.set({
    [key]: existing,
    [STORAGE_KEY_QUEUE]: queue
  });
}
async function getBackendUrl() {
  const result = await chrome.storage.local.get(STORAGE_KEY_CONFIG);
  return result[STORAGE_KEY_CONFIG] ?? DEFAULT_BACKEND_URL;
}
async function isContributing() {
  const result = await chrome.storage.local.get("config:contributing");
  return result["config:contributing"] !== false;
}
async function flushSyncQueue() {
  if (!await isContributing()) {
    console.log("[Commit] Contributing disabled — skipping sync");
    return;
  }
  const backendUrl = await getBackendUrl();
  const result = await chrome.storage.local.get(STORAGE_KEY_QUEUE);
  const queue = result[STORAGE_KEY_QUEUE] ?? [];
  if (queue.length === 0)
    return;
  const authResult = await chrome.storage.local.get("auth:credential");
  const credential = authResult["auth:credential"];
  if (!credential?.idToken) {
    console.log("[Commit] No World ID credential — skipping sync (sign in required)");
    return;
  }
  try {
    const res = await fetch(`${backendUrl}/api/commit`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${credential.idToken}`
      },
      body: JSON.stringify(queue)
    });
    if (res.ok) {
      const afterResult = await chrome.storage.local.get(STORAGE_KEY_QUEUE);
      const afterQueue = afterResult[STORAGE_KEY_QUEUE] ?? [];
      const remaining = afterQueue.slice(queue.length);
      await chrome.storage.local.set({ [STORAGE_KEY_QUEUE]: remaining });
      console.log(`[Commit] Synced ${queue.length} commitments to backend`);
    } else {
      console.warn(`[Commit] Backend sync failed: HTTP ${res.status} — will retry`);
    }
  } catch (err) {
    console.warn("[Commit] Backend unreachable — queued for next sync:", err);
  }
}
async function setupSyncAlarm() {
  const existing = await chrome.alarms.get(SYNC_ALARM_NAME);
  if (!existing) {
    chrome.alarms.create(SYNC_ALARM_NAME, {
      periodInMinutes: SYNC_INTERVAL_MINUTES
    });
    console.log(`[Commit] Sync alarm set: every ${SYNC_INTERVAL_MINUTES} minutes`);
  }
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SYNC_ALARM_NAME) {
    await flushSyncQueue();
  }
});
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    const domain = tab.url ? extractDomain(tab.url) : null;
    await switchDomain(domain);
  } catch {
    await switchDomain(null);
  }
});
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url && tab.active) {
    const domain = extractDomain(changeInfo.url);
    await switchDomain(domain);
  }
});
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await switchDomain(null);
  } else {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        windowId
      });
      const domain = tab?.url ? extractDomain(tab.url) : null;
      await switchDomain(domain);
    } catch {
      await switchDomain(null);
    }
  }
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes["auth:credential"]) {
    const newValue = changes["auth:credential"].newValue;
    if (newValue) {
      console.log("[Commit] User authenticated:", newValue.verificationLevel);
      flushSyncQueue().catch(console.warn);
    } else {
      console.log("[Commit] User signed out");
    }
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "contributing-changed") {
    console.log("[Commit] Contributing toggled:", message.value);
    if (message.value) {
      flushSyncQueue().catch(console.warn);
    }
    sendResponse({ ok: true });
  }
});
async function init() {
  await setupSyncAlarm();
  await flushSyncQueue();
}
init().catch(console.error);
console.log("[Commit] Background service worker started");
