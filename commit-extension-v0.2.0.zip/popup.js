// src/extension/auth.ts
var WORLD_ID_APP_ID = "app_a2868bad17534bb7e8bc82de8df73773";
var WORLD_ID_AUTHORIZE_URL = "https://id.worldcoin.org/authorize";
var WORLD_ID_JWKS_URL = "https://id.worldcoin.org/jwks.json";
var WORLD_ID_ISSUER = "https://id.worldcoin.org";
var STORAGE_KEY_AUTH = "auth:credential";
function generateNonce() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(16).padStart(2, "0")).join("");
}
function generateState() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (b) => b.toString(16).padStart(2, "0")).join("");
}
function base64urlDecode(str) {
  let base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4 !== 0) {
    base64 += "=";
  }
  return atob(base64);
}
function parseJWT(token) {
  const parts = token.split(".");
  if (parts.length !== 3)
    throw new Error("Invalid JWT format");
  const header = JSON.parse(base64urlDecode(parts[0]));
  const payload = JSON.parse(base64urlDecode(parts[1]));
  return { header, payload };
}
async function importJWK(jwk) {
  return crypto.subtle.importKey("jwk", {
    kty: jwk.kty,
    n: jwk.n,
    e: jwk.e,
    alg: jwk.alg,
    use: jwk.use
  }, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
}
async function verifyJWTSignature(token, key) {
  const parts = token.split(".");
  const signedContent = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
  const signatureStr = parts[2].replace(/-/g, "+").replace(/_/g, "/");
  const paddedSig = signatureStr + "=".repeat((4 - signatureStr.length % 4) % 4);
  const signatureBytes = Uint8Array.from(atob(paddedSig), (c) => c.charCodeAt(0));
  return crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, signatureBytes, signedContent);
}
async function fetchSigningKey(kid) {
  const response = await fetch(WORLD_ID_JWKS_URL);
  if (!response.ok) {
    throw new Error(`Failed to fetch JWKS: ${response.status}`);
  }
  const jwks = await response.json();
  const key = jwks.keys.find((k) => k.kid === kid);
  if (!key) {
    throw new Error(`No matching key found for kid: ${kid}`);
  }
  return importJWK(key);
}
async function verifyIdToken(idToken, expectedNonce) {
  const { header, payload } = parseJWT(idToken);
  if (payload.iss !== WORLD_ID_ISSUER) {
    throw new Error(`Invalid issuer: ${payload.iss}`);
  }
  if (payload.aud !== WORLD_ID_APP_ID) {
    throw new Error(`Invalid audience: ${payload.aud}`);
  }
  if (payload.nonce !== expectedNonce) {
    throw new Error("Nonce mismatch");
  }
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) {
    throw new Error("Token expired");
  }
  const signingKey = await fetchSigningKey(header.kid);
  const valid = await verifyJWTSignature(idToken, signingKey);
  if (!valid) {
    throw new Error("Invalid token signature");
  }
  return payload;
}
function getRedirectURL() {
  return chrome.identity.getRedirectURL("/callback");
}
async function signIn() {
  const nonce = generateNonce();
  const state = generateState();
  const redirectUri = getRedirectURL();
  const params = new URLSearchParams({
    client_id: WORLD_ID_APP_ID,
    response_type: "id_token",
    redirect_uri: redirectUri,
    scope: "openid",
    state,
    nonce,
    response_mode: "fragment"
  });
  const authUrl = `${WORLD_ID_AUTHORIZE_URL}?${params.toString()}`;
  const responseUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true
    }, (callbackUrl) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!callbackUrl) {
        reject(new Error("No callback URL received"));
        return;
      }
      resolve(callbackUrl);
    });
  });
  const hashParams = new URLSearchParams(responseUrl.split("#")[1] || "");
  const returnedState = hashParams.get("state");
  if (returnedState !== state) {
    throw new Error("State mismatch — possible CSRF attack");
  }
  const idToken = hashParams.get("id_token");
  if (!idToken) {
    const error = hashParams.get("error");
    const errorDesc = hashParams.get("error_description");
    throw new Error(`Authentication failed: ${error || "no id_token"} — ${errorDesc || "unknown error"}`);
  }
  const payload = await verifyIdToken(idToken, nonce);
  const credential = {
    sub: payload.sub,
    verificationLevel: payload.verification_level || "unknown",
    authenticatedAt: Date.now(),
    idToken
  };
  await chrome.storage.local.set({ [STORAGE_KEY_AUTH]: credential });
  return credential;
}
async function signOut() {
  await chrome.storage.local.remove(STORAGE_KEY_AUTH);
}
async function getCredential() {
  const result = await chrome.storage.local.get(STORAGE_KEY_AUTH);
  return result[STORAGE_KEY_AUTH] || null;
}

// src/extension/popup.ts
var BACKEND_URL = "https://poc-backend.amdal-dev.workers.dev";
var authOverlay = document.getElementById("auth-overlay");
var authBtn = document.getElementById("auth-btn");
var skipBtn = document.getElementById("skip-btn");
var authErrorEl = document.getElementById("auth-error");
var authPill = document.getElementById("auth-pill");
var authDot = document.getElementById("auth-dot");
var authLabel = document.getElementById("auth-label");
var siteDomainEl = document.getElementById("site-domain");
var scoreArc = document.getElementById("score-arc");
var scoreValue = document.getElementById("score-value");
var trustSignals = document.getElementById("trust-signals");
var noData = document.getElementById("no-data");
var sigVisitors = document.getElementById("sig-visitors");
var sigRepeat = document.getElementById("sig-repeat");
var sigTime = document.getElementById("sig-time");
var myTime = document.getElementById("my-time");
var myVisits = document.getElementById("my-visits");
var mySince = document.getElementById("my-since");
var contributeToggle = document.getElementById("contribute-toggle");
var footerStat = document.getElementById("footer-stat");
var brregSection = document.getElementById("brreg-section");
var brregLink = document.getElementById("brreg-link");
var brregDetails = document.getElementById("brreg-details");
function formatTime(seconds) {
  if (seconds < 60)
    return `${seconds}s`;
  if (seconds < 3600)
    return `${Math.round(seconds / 60)}m`;
  const hours = Math.floor(seconds / 3600);
  const mins = Math.round(seconds % 3600 / 60);
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}
function formatDate(timestamp) {
  const d = new Date(timestamp);
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  return `${months[d.getMonth()]} ${d.getDate()}`;
}
function formatNumber(n) {
  if (n >= 1e6)
    return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1000)
    return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}
function extractDomain(url) {
  try {
    const parsed = new URL(url);
    if (["chrome:", "chrome-extension:", "about:", "edge:"].includes(parsed.protocol)) {
      return null;
    }
    return parsed.hostname;
  } catch {
    return null;
  }
}
function setScoreRing(score) {
  const circumference = 2 * Math.PI * 15;
  const filled = score / 100 * circumference;
  scoreArc.setAttribute("stroke-dasharray", `${filled} ${circumference}`);
  scoreValue.textContent = String(score);
  let color = "#f87171";
  if (score >= 70)
    color = "#4ade80";
  else if (score >= 40)
    color = "#facc15";
  scoreArc.setAttribute("stroke", color);
}
function showAuthState(credential) {
  if (credential) {
    authOverlay.classList.add("hidden");
    authPill.className = "auth-pill verified";
    authDot.className = "dot green";
    const level = credential.verificationLevel === "orb" ? "Orb verified" : credential.verificationLevel === "device" ? "Device verified" : "Verified";
    authLabel.textContent = level;
  } else {
    authPill.className = "auth-pill unverified";
    authDot.className = "dot gray";
    authLabel.textContent = "Not verified";
    chrome.storage.local.get("auth:skipped", (result) => {
      if (result["auth:skipped"]) {
        authOverlay.classList.add("hidden");
      } else {
        authOverlay.classList.remove("hidden");
      }
    });
  }
}
async function handleSignIn() {
  authBtn.textContent = "Verifying...";
  authBtn.disabled = true;
  authErrorEl.style.display = "none";
  try {
    const credential = await signIn();
    showAuthState(credential);
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    if (msg.includes("canceled") || msg.includes("cancelled") || msg.includes("user denied")) {} else {
      authErrorEl.textContent = msg;
      authErrorEl.style.display = "block";
    }
  } finally {
    authBtn.textContent = "Verify with World ID";
    authBtn.disabled = false;
  }
}
function handleSkip() {
  chrome.storage.local.set({ "auth:skipped": true });
  authOverlay.classList.add("hidden");
}
async function handleSignOut() {
  await signOut();
  await chrome.storage.local.remove("auth:skipped");
  showAuthState(null);
}
async function fetchSiteTrust(domain) {
  try {
    const res = await fetch(`${BACKEND_URL}/api/domain/${encodeURIComponent(domain)}`);
    if (!res.ok)
      return null;
    return await res.json();
  } catch {
    return null;
  }
}
function displaySiteTrust(stats) {
  if (!stats || stats.uniqueCommitments === 0) {
    trustSignals.style.display = "none";
    noData.style.display = "block";
    scoreValue.textContent = "--";
    scoreArc.setAttribute("stroke-dasharray", "0 94.2");
    return;
  }
  trustSignals.style.display = "grid";
  noData.style.display = "none";
  sigVisitors.textContent = formatNumber(stats.uniqueCommitments);
  const repeatRate = stats.totalVisits > stats.uniqueCommitments ? Math.round((stats.totalVisits - stats.uniqueCommitments) / stats.totalVisits * 100) : 0;
  sigRepeat.textContent = `${repeatRate}%`;
  const avgMin = stats.avgSeconds > 0 ? Math.round(stats.avgSeconds / 60) : 0;
  sigTime.textContent = avgMin > 0 ? `${avgMin}m` : "<1m";
  let score = 0;
  score += Math.min(stats.uniqueCommitments * 4, 40);
  score += Math.round(repeatRate * 0.35);
  score += Math.min(avgMin * 2.5, 25);
  score = Math.min(Math.round(score), 100);
  setScoreRing(score);
}
async function displayYourCommitment(domain) {
  const key = `visit:${domain}`;
  const result = await chrome.storage.local.get(key);
  const visit = result[key];
  if (visit) {
    myTime.textContent = formatTime(visit.totalSeconds);
    myVisits.textContent = String(visit.visitCount);
    mySince.textContent = formatDate(visit.firstSeen);
  } else {
    myTime.textContent = "0s";
    myVisits.textContent = "0";
    mySince.textContent = "Now";
  }
}
async function updateFooterStats() {
  const all = await chrome.storage.local.get(null);
  let siteCount = 0;
  for (const key of Object.keys(all)) {
    if (key.startsWith("visit:"))
      siteCount++;
  }
  footerStat.textContent = `${siteCount} site${siteCount !== 1 ? "s" : ""} tracked`;
}
async function initContributeToggle() {
  const result = await chrome.storage.local.get("config:contributing");
  const isContributing = result["config:contributing"] !== false;
  contributeToggle.checked = isContributing;
  contributeToggle.addEventListener("change", () => {
    chrome.storage.local.set({ "config:contributing": contributeToggle.checked });
    chrome.runtime.sendMessage({ type: "contributing-changed", value: contributeToggle.checked });
  });
}
async function checkBrregData(domain) {
  if (!domain.endsWith(".no")) {
    brregSection.style.display = "none";
    return;
  }
  brregSection.style.display = "block";
  const nameParts = domain.replace(/\.no$/, "").split(".");
  const guess = nameParts[nameParts.length - 1] ?? domain;
  if (guess.length < 3) {
    brregSection.style.display = "none";
    return;
  }
  brregLink.addEventListener("click", async () => {
    if (brregDetails.classList.contains("visible")) {
      brregDetails.classList.remove("visible");
      return;
    }
    brregDetails.innerHTML = "Searching Brønnøysund...";
    brregDetails.classList.add("visible");
    try {
      const res = await fetch(`${BACKEND_URL}/api/business/search?q=${encodeURIComponent(guess)}&limit=1`);
      if (!res.ok) {
        brregDetails.innerHTML = "Could not reach business registry.";
        return;
      }
      const data = await res.json();
      if (data.count === 0) {
        brregDetails.innerHTML = `No businesses found matching "${guess}".`;
        return;
      }
      const biz = data.results[0];
      brregDetails.innerHTML = `
        <strong style="color:#fff">${biz.name}</strong> (${biz.orgNumber})<br/>
        ${biz.industry ? `Industry: ${biz.industry}<br/>` : ""}
        ${biz.employees !== null ? `Employees: ${biz.employees}<br/>` : ""}
        ${biz.yearsOperating !== null ? `Operating: ${biz.yearsOperating} years<br/>` : ""}
        <br/>
        Commitment signals:<br/>
        <span class="brreg-score">Overall: ${biz.signals.overall}/100</span> &middot;
        Temporal: ${biz.signals.temporal} &middot;
        Financial: ${biz.signals.financial} &middot;
        Operational: ${biz.signals.operational}
      `;
    } catch {
      brregDetails.innerHTML = "Error loading business data.";
    }
  });
}
authPill.addEventListener("click", async () => {
  const credential = await getCredential();
  if (credential) {
    if (confirm("Sign out of Commit?")) {
      await handleSignOut();
    }
  } else {
    authOverlay.classList.remove("hidden");
  }
});
authBtn.addEventListener("click", handleSignIn);
skipBtn.addEventListener("click", handleSkip);
async function init() {
  const credential = await getCredential();
  showAuthState(credential);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const domain = tab?.url ? extractDomain(tab.url) : null;
  if (domain) {
    siteDomainEl.textContent = domain;
    const [siteStats] = await Promise.all([
      fetchSiteTrust(domain),
      displayYourCommitment(domain)
    ]);
    displaySiteTrust(siteStats);
    checkBrregData(domain);
  } else {
    siteDomainEl.textContent = "No site";
    trustSignals.style.display = "none";
    noData.style.display = "block";
    noData.textContent = "Navigate to a website to see trust data.";
    myTime.textContent = "--";
    myVisits.textContent = "--";
    mySince.textContent = "--";
  }
  await Promise.all([
    updateFooterStats(),
    initContributeToggle()
  ]);
}
init();
